const micros = [
    {
      micro: 'Sinclair ZX Spectrum',
      imagen: 'sinclair_zx_spectrum.png',
      precio: 250
    },
    {
      micro: 'Sinclair ZX 81',
      imagen: 'Sinclair_ZX81.png',
      precio: 300
    },
    {
      micro: 'Atari 800',
      imagen: 'atari_800.png',
      precio: 250
    },
    {
      micro: 'Commodore 64Kb',
      imagen: 'commodore_64.png',
      precio: 200
    },
    {
      micro: 'Commodore Amiga 500',
      imagen: 'commodore_amiga.png',
      precio: 500
    },
    {
      micro: 'Dragon 32',
      imagen: 'dragon_32.png',
      precio: 220
    },
    {
      micro: 'Tandy New Brain',
      imagen: 'new_brain.png',
      precio: 400
    },
    {
      micro: 'Oric Atmos',
      imagen: 'oric_atmos.png',
      precio: 300
    },
    {
      micro: 'Toshiba MSX HitBit',
      imagen: 'toshiba_msx.png',
      precio: 350
    },
  ]

  export default micros